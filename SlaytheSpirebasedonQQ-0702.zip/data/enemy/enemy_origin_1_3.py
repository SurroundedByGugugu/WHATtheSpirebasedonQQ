# -*- coding: utf-8 -*-
# enemy_origin_1_3 表示来自原作1中三层怪物/事件怪物。

import random

from data.enemy.base_enemy import EnemyIntent
from data.enemy.pattern_enemy import PatternEnemy


ORB_WALKER_A = EnemyIntent(
    kind="multi",
    actions=[
        EnemyIntent(kind="attack", value=10, attack_type="blunt"),
        EnemyIntent(kind="add_card_to_draw", card_id="card.status.burn_i", count=1),
        EnemyIntent(kind="add_card_to_discard", card_id="card.status.burn_i", count=1),
    ],
)
ORB_WALKER_B = EnemyIntent(
    kind="attack",
    value=15,
    attack_type="blunt",
)
class OrbWalkerEnemy(PatternEnemy):
    def __init__(self, max_hp=None):
        PatternEnemy.__init__(
            self,
            enemy_id="enemy.orb_walker",
            name="圆球行者",
            max_hp=max_hp if max_hp is not None else random.randint(90, 96),
            intent_cycle=[ORB_WALKER_A, ORB_WALKER_B],
        )
        self._orb_intent_history = []

        # 战斗开始时自带 3 层“每回合结束获得力量”的状态。
        # 当前工程里敌人 ritual 已按敌方回合结束触发。
        self.gain_status("ritual", 3)

    def _resolve_intent_slot(self, slot):
        choices = [ORB_WALKER_A, ORB_WALKER_B]
        history = list(getattr(self, "_orb_intent_history", []) or [])

        if len(history) >= 2 and history[-1] is history[-2]:
            chosen = ORB_WALKER_B if history[-1] is ORB_WALKER_A else ORB_WALKER_A
        else:
            chosen = random.choice(choices)

        history.append(chosen)
        if len(history) > 2:
            history = history[-2:]

        self._orb_intent_history = history
        return chosen

    def advance_intent(self):
        self._locked_intent = None
def create_orb_walker():
    return OrbWalkerEnemy()

